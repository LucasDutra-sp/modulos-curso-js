function criarPessoa() {
    return {
        nome: 'Mayara',
        sobrenome: 'Ribeiro'
    }
}

console.log(criarPessoa())

console.log("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")

function criarProdutos(nome, preco) {
    return {
        nome,
        preco,
        desconto: 0.1
    }
}

console.log(criarProdutos('notebook', 2199,49))
console.log(criarProdutos("iPed", 1299,49))