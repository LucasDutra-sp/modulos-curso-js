const aprovados = ['agatha', 'aldo', 'daniel', 'raquel']

aprovados.forEach(function(nome, indice) {
    console.log(`${indice + 1} -> ${nome}`)
})

//arrow function
aprovados.forEach(nome => console.log(nome))

//armazenando função em variavel
const exibirAprovados = aprovado => console.log(aprovado)
aprovados.forEach(exibirAprovados)