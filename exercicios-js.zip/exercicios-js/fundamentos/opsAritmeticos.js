const [a, b, c, d] = [3, 5, 1, 15]

const soma = a+b+c+d
const subtracao = d - b
const multp = a*b
const divisao = c / d
const modulo = b % 2

console.log(soma, subtracao, multp, divisao.toFixed(4), modulo)