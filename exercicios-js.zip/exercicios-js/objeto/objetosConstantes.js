//pessoa -> (endereço de memoria X) -> {...}
const pessoa = { nome: 'joao' }
pessoa.nome = 'pedro'
console.log(pessoa.nome)

//pessoa -> (endereço de memoria Y) -> {...}
/*pessoa = {nome: 'ana'}*/

Object.freeze(pessoa) //impossibilita qualquer tipo de edição no objeto em questão

pessoa.nome = 'maria'
pessoa.end = 'Rua ABC'
delete pessoa.nome

console.log(pessoa)
console.log(pessoa.nome)

const pessoaConstante = Object.freeze({nome: 'Lucas'})
console.log(pessoaConstante)