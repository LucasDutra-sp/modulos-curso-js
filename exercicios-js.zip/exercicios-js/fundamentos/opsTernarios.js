const resultado = nota => nota >= 7 ? 'aprovado' : 'reprovado'

console.log(resultado(4))
console.log(resultado(6.9))
console.log(resultado(7.4))

/*
pode ser feito:

const resultado = nota => {
    return nota >= 7 ? 'aprovado' : 'reprovado'
}
*/