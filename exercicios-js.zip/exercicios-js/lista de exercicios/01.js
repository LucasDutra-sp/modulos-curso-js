const ops = function operacoes (a, b=0) {
    soma = a + b
    sub = a - b
    mult = a * b
    div = a / b

    return console.log(`soma: ${soma},
subtração: ${sub},
multiplicação: ${mult},
divisão: ${div}.
fim.`)
}

ops(44, 4)
ops(9)