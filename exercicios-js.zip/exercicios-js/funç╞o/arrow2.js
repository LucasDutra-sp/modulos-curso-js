//o this não varia em arrow functions

function pessoa() {
    this.idade = 0

    setInterval(() => {
        this.idade++
        console.log(this.idade)
    }, 750) //tempo em ms
}

new pessoa