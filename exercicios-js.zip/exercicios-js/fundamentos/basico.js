console.log("Essa sintaxe forma uma string e a transcreve")
//isso é um comentario de uma linha

/*
isso é
um comentario
de varias linhas
*/

var X = 10 //variável
let Y = 25 //variável
const Z = 50 //constante

console.log(X, Y, Z)

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
//hoisting (içamento)

console.log('valor de a =', a)
var a = 2
console.log('valor de a =', a)

/*console.log(b)
let b = 4
console.log(b)*/
//içamento nõo funciona com Let