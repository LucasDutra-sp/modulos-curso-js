//Var só possuem dois escopos possiveis: global e de função
{
    {
        {
            {
                var X = ('okay')
                console.log(X)
            }
        }
    }
}
console.log(X)

function teste() {
    var Y = (123)
    console.log(Y)
}
teste()
console.log(Y) //o determinante de "Y" não pode ser encontrado fora da função