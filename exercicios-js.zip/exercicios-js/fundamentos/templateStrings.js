//em templateStrings podem haver quebras de linha e outras coisas
const nome = "Lucas"
const concatenaçao = 'Olá sr ' + nome + '!'
const template = `
    Olá
    sr  ${nome}!
    tudo bem?` //deve se usar ${} para adicionar dados dentro de T.strings
console.log(concatenaçao, template)

//expressoes...
console.log(`8 + 6 = ${8+6}`)

const up = texto => texto.toUpperCase()
    //função "=>" será explicada posteriormente

console.log(`ei... ${up("cuidado")}!`)