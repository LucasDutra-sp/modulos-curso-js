function rand({ min = 0000, max = 1001 }) {
    const valor = Math.random() * (max - min) + min
    return Math.floor(valor)
}
console.log(rand({}))

const obj = { max: 50, min: 40 }
console.log(rand(obj))