//Let têm três escopos: global, de função e de bloco
let numero = 1
{
    let numero = 2
    console.log(numero)
}
console.log(numero)