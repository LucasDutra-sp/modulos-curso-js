const valores = [55, 8.4, 144, 6.0]
console.log(valores[0], valores[3])
console.log(valores[7])

valores[7] = 25
console.log(valores[7])
console.log(valores.length)

valores.push(`${1+1}`, "ovo", 4)
console.log(valores)

console.log(valores.pop())
delete valores[0]
console.log(valores)

console.log(typeof valores)