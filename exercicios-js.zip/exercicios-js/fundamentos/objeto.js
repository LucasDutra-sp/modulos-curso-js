const prod1 = {}
prod1.nome = 'Relógio'
prod1.preço = 200.00
prod1['desconto 20%'] = `${(prod1.preço)/5*4}`
prod1["desconto 28%"] = `${(prod1.preço)-(prod1.preço)/100*28}`
//evitar atributos com espaço
console.log(prod1)

const prod2 = {
    nome: 'Jaqueta', //necessario adicionar virgula
    preço: 80.00,
    ['desconto 25%']: `${80/4*3}`
}
console.log(prod2)