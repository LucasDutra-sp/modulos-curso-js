const pilotos = ['Vettel', 'Alonso', 'Raikkonen', 'Massa']
pilotos.pop() //remove o ultimo elemento do array

pilotos.push('Verstappen') //adiciona um elemento ao final do array (ou a uma lacuna, se existir)

pilotos.shift() //remove o primeiro elemento do array

pilotos.unshift('Hamilton') //adiciona elementos ao inicio do array
console.log(pilotos)

//splice pode adicionar e/ou remover multiplos elementos de um array

pilotos.splice(2, 2, 'Bottas', pilotos[2], pilotos[3])
/*             ^  ^   ^        ^           ^
               ^  ^   ^elementos a serem adicionados ao array
               ^  ^
               ^  ^numero de indices a serem removidos
               ^
               ^a partir do índice:
*/

console.log(pilotos)

const algunsPilotos1 = pilotos.slice(2) //forma um novo array com os elementos a partir de tal indice
console.log(algunsPilotos1)

const algunsPilotos2 = pilotos.slice(1, 4) //não inclui no array, o indice indicado como final
console.log(algunsPilotos2)