const estaveis = ['lítio 3', 'carbono 6']
const radioativos = ['césio 55', 'uranio 92']
const todos = estaveis.concat(radioativos)
console.log(todos)

console.log([].concat([1, 2], ['três', 'quatro'], 5, [[6, 7]], 'oito'))