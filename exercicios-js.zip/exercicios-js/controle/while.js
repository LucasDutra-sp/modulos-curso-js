function getInteiroAleatorioEntre(min, max) {
    const valor = Math.random() * (max - min) + min
    return Math.floor(valor)
}

let opcao = 999999 //apenas criando a variavel que será usada dentro da estrutura de controle

while(opcao != -1) {
    opcao = getInteiroAleatorioEntre(-1, 25)
    console.log(`A opção escolhida foi ${opcao}.`)
}
//console.log('Até a próxima!')

console.log('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')

function getInteiroAleatorioEntre(min, max) {
    const valor = Math.random() * (max - min) + min
    return Math.floor(valor)
}

opcao = -1

do {
    opcao = getInteiroAleatorioEntre(-1, 25)
    console.log(`A opção escolhida foi ${opcao}.`)
} while (opcao != -1)
console.log('Até a próxima!')
//do while sempre executará ao menos uma repetição, independente do valor do parametro