//estrategia 1 para gerar valor padrão
function soma1(a,b,c) {
    a = a || 1
    b = b || 1
    c = c || 1
    return a+b+c
}

console.log(soma1(), soma1(90, 9), soma1(0, 0, 0))

//estrategia 2, 3 e 4 para gerar valor padrão
function soma2(a, b, c) {
    a = a != undefined ? a : 1 //"se A é diferente de und., assuma A. se não, 1."
    b = 1 in arguments ? b : 1 //"in arguments da função existe o indice 1? (sim: B, não: 1)"
    c = isNaN(c) ? 1 : c //"C = NaN? assuma 1. se não, assuma C"
    //C opção mais segura
    return a + b + c
}

console.log(soma2(), soma2(0, 2, 23), soma2('y', 'y', 'y'))

//valor padrão ES2015
function soma3 (a = 1, b = 1, c =1) {
    return a + b + c
}

console.log(soma3(), soma3(3), soma3(0, 0, 0))