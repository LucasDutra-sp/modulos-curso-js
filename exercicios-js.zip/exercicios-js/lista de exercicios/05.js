const converter = function (a = 0, b=0, c=0, d=0) {
    valor = a + b + c + d
    return console.log(`R$ ${valor.toFixed(2)}`)
}

converter(0.1, 0.2)
converter(999.25, 2323, 90, 845.50)