function teste1(num) {
    if(num > 7)
        console.log(num) //quando sem uso de chaves, a funçao IF irá abranger somente a linha ulterior
        console.log('final') //essa linha será executada independente de cumprir ou não o requisito IF
}

teste1(6)
teste1(8)

console.log("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")

const teste2 = function(num) {
    if(num < 10); { //o ';' está encerrando a linha de comando do IF, dessa forma tudo após o ';' será executado
        console.log(++num)
    }
}

teste2(30)
teste2(14)
teste2(0.7)