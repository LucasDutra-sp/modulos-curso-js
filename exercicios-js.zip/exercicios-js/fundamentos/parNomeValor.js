//par nome/valor
const saudacao = 'opa!' //contexto léxico 1

function exec() {
    const saudacao = 'eae!' //contexto léxico 2
    return saudacao
}
console.log(saudacao)
console.log(exec())

//Objetos são grupos aninhados de pares nome/valor
const cliente = {
    nome: 'pedro',
    idade: 32,
    peso: 70,
    endereço: {
        logradouro: "Rua dos bobos",
        numero: 0,
        complemento: ''
    }
}
console.log(cliente)