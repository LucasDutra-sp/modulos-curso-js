//função sem retorno
function imprimirSoma(a, b) {
    console.log(a + b)
}

imprimirSoma(2, 4)
imprimirSoma(2)
imprimirSoma(2,4,5,12,74)
imprimirSoma()

//função com retorno
function soma(a, b = 7) {
    return a + b
}

console.log(soma(2, 3))
console.log(soma(2))

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

//armazenando uma função em uma variavel
const adiçao = function (a,b) {
    console.log(a + b)
}
adiçao(4,20)

//armazenando função arrow em uma variavel
const divisao = (a, b) => {
    return a / b
}
console.log(divisao(200, 25))

//retorno implicito
const subtraçao = (a, b) => a - b
console.log(subtraçao(2,8))

const imprimir = a => console.log(a)
imprimir("AAAAAAAA")
