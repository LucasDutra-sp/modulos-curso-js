//BOOLEAN = basicamente um valor verdadeiro/falso

console.log(!!8)
console.log(!!-1)
console.log(!!' ')
console.log(!![])
console.log(!!{})
console.log(!!Infinity)
//verdadeiros

console.log(!!0)
console.log(!!'')
console.log(!!null)
console.log(!!NaN)
console.log(!!undefined)    
//falsos

{
    console.log(null || 0 || '' || "texto")
    console.log(!!(null || 0 || '' || "texto"))
    //função "ou" (||) considera e retorna apenas o primeiro valor não-nulo da expressão

    let nome = ""
    console.log(nome||'desconhecido')

    nome = "Lucas"
    console.log(nome||'desconhecido')
}