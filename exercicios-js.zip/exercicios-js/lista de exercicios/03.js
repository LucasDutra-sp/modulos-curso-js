const elev = function elevar (a, b) {
    console.log(Math.pow(a, b))
}

elev(2, 10)
elev(10, 6)