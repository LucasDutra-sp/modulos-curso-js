let num1 = 01
let num2 = 02

num1++ //pos-fixado (tem menos prioridade na execuçao)
console.log(num1)

--num1 //pre-fixado (tem mais prioridade)
console.log(num2)

console.log(++num1 === num2--) //a comparaçao é feita antes de subtrair de "num2"