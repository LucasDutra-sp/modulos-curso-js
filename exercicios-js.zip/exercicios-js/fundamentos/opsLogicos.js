/*
Historinha:
voce trabalha com freelance quando aparecem oportunidades.
voce tem dois trabalhos na semana, um na terça-feira e outro na quinta.
caso dê certo ambos os trabalhos, voce comprará uma TV de 50" e tomará um sorvete;
caso um execute um trabalho e o outro nao, comprará uma TV 32" e tambem vai tomar sorvete;
caso nada dê certo, nao vai comprar nada, entretanto, ficará saudavel.
*/

function compras(trabalho1, trabalho2) {
    const comprarSorvete = trabalho1 || trabalho2
    const comprarTv50 = trabalho1 && trabalho2
    const comprarTv32 = trabalho1 != trabalho2
    const manterSaudavel = !comprarSorvete //operador unário
    
    return { comprarSorvete, comprarTv50, comprarTv32, manterSaudavel }
}

console.log(compras(true, true))
console.log(compras(true, false))
console.log(compras(false, true))
console.log(compras(false, false))