const funcvar = []

for (var i = 0; i < 10; i++) {
    funcvar.push(function() {
        console.log(i)
    })
}

funcvar[2]()
funcvar[8]()

const funclet = []

for (let i = 0; i < 10; i++) {
    funclet.push(function() {
        console.log(i)
    })
}

funclet[2]()
funclet[8]()