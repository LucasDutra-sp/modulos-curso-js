const produtos = [
    { nome: 'notebook', preco: 2499, fragil: true },
    { nome: 'iPad pro', preco: 4199, fragil: true },
    { nome: 'copo de vidro', preco: 12.50, fragil: true },
    { nome: 'copo de plastico', preco: 18.99, fragil: false }
]

console.log(produtos.filter(function(p) {
    return false
}))

let fragil = f => f.fragil //não é necessario "== true" pq o atributo já é booleano
let caro = c => c.preco >= 500

console.log(produtos.filter(fragil).filter(caro))