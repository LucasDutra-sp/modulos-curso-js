function tratarErroELancar(erro) {
    //throw new Error("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA")
    //throw 145
    //throw true
    //throw "alguma string"
    throw {
        nome: erro.name,
        msg: erro.message,
        date: new Date
    }   
}

function imprimirNomeGritado(obj) {
    try {
        console.log(obj.name.toUpperCase() + '!!!!') //funçao com algum potencial de erro
    } catch (xls) {
        tratarErroELancar(xls)
    } finally { //será chamado independente de ocorrer o erro ou não
        console.log('final')
    }
}

const obj = { nome: 'Danielly' } //o erro está na divergencia [nome/name]
imprimirNomeGritado(obj)