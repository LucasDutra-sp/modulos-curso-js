// Object.preventExtensions
const produto = Object.preventExtensions({
    nome: 'qualquer', preco: 1.99, tag: 'promoção'
})
console.log("Extensível:", Object.isExtensible(produto)) //testa se o objeto pode ou não ser extendido

produto.nome = 'borracha'
produto.descricao = 'borracha branca escolar'
delete produto.tag
console.log(produto)

// Object.seal
//objetos selados não podem receber atributos e nem deletar os mesmos
const pessoa = {nome: 'Juliana', idade: 35}
Object.seal(pessoa)
console.log('Selado:', Object.isSealed(pessoa)) //testa se o objeto está selado

pessoa.sobrenome = 'Silva'
delete pessoa.nome
pessoa.idade = 29
console.log(pessoa)

// Object.freeze = selado + valores constantes (writable: false)