const a = 3
let b = 7

b += a //b = b + a
console.log(b)

b -= 4 //b = b - 4
console.log(b)

b *= 2 //b = b * 2
console.log(b)

b /= 3 //b = b / 3
console.log(b)

b %= 2 //NÃO é porcentagem
console.log(b)
//o operador de Modulo retorna o RESTO da divisão do primeio termo, pelo segundo