const div = function divComResto (a, b) {
    c = a/b
    console.log(c)
    console.log(`resto: ${a%b}.`)
}

div(4, 2)
div(500, 24)
div(5, 2)