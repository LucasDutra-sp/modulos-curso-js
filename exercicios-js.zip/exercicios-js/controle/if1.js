function soBoaNoticia(nota) {
    if(nota >= 7) {
        console.log('aprovado com ' + nota)
    }
}

soBoaNoticia(7.8)
soBoaNoticia(6.4)

function seForVerdadeEuFalo(valor) {
    if(valor) {
        console.log("é verdade... " + valor)
    }
}

seForVerdadeEuFalo()
seForVerdadeEuFalo(300)