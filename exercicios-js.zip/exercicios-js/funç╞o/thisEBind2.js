function pessoa() {
    this.idade = 0

    const self = this //criar constante para acessar o this
    setInterval(function() {
        self.idade++
        console.log(self.idade)
    }/*.bind(this)*/, 1000)
}

new pessoa

//para parar o codigo: ctrl + alt + M