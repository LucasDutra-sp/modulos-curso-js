//desestruturando a partir de um objeto
const pessoa = {
    nome: 'Dante',
    idade: 18,
    endereço: {
        logradouro: 'Rua DMC',
        numero: 616
    }
}

const { nome, idade } = pessoa
console.log(nome,idade)

const { nome: n, idade: i} = pessoa
console.log(n, i)

const { sobrenome, bemHumorado = true } = pessoa
console.log(sobrenome,bemHumorado)

const { endereço: { logradouro, numero, cep } } = pessoa
console.log(logradouro, numero, cep)