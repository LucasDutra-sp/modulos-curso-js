function soma() {
    let soma = 0 //o '0' seta a variavel para o tipo Number
    for (i in arguments) {
        soma += arguments[i]
    }
    return soma
}

console.log(soma())
console.log(soma(1, 2, 3))
console.log(soma(9, 7, " batatinhas"))
console.log(soma(' I', " am", ` Iron Man`))