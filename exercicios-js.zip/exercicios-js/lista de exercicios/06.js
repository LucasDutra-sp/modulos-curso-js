const simples = function (capital, juros, tempo) {
    total = capital + (capital*juros) * tempo

    return console.log(`R$ ${total}.`)
}

simples(100, 0.10, 6)