Number.prototype.entre = function (inicio, fim) {
    return this >= inicio && this <= fim
}

function imprimirResultado(nota) {
    if(nota.entre(9.5, 10)) {
        console.log("Quadro de Honra")
    } else if (nota.entre(7,9.49)) {
        console.log('aprovado')
    } else if(nota.entre(4, 6.99)) {
        console.log('recuperação')
    } else if (nota.entre(0,3.99)) {
        console.log('reprovado')
    } else {
        console.log('nota inválida')
    }
    console.log("Boas férias!")
}

imprimirResultado(9.80)
imprimirResultado(8.25)
imprimirResultado(5)
imprimirResultado(2.95)
imprimirResultado(-7)
imprimirResultado(10.1)