Array.prototype.map2 = function(callback) {
    let newArray = []
    for (let i = 0; i < this.length; i++) {
        newArray.push(callback(this[i], i, this))
    }
    return newArray
}

const nums = [1, 2, 3, 4, 5]

const soma15 = function(e) {
    return e + 15
}

console.log(nums.map2(soma15))