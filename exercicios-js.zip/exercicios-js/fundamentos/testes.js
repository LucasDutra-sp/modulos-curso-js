/*
meus atalhos:

save= alt,s
clear output= alt,x
run code= padrão
*/

console.log(Math.pow(12, 2))
console.log(`${64 * -2}`) //possivel apenas usando T.string

