const carro = "Corvette"

console.log(carro.charAt(3)) //transcreve o caractere relativo ao índice requerido
console.log(carro.charCodeAt(0)) //retorna o caractere, convertido em codigo HTML

console.log(carro.indexOf('e'))

console.log(carro.substring(3))
console.log(carro.substring(2, 7))
//.substring retorna os dados/strings de acordo com o(s) indice(s) requeridos

console.log('Aquele '.concat(carro).concat(' é lindo!'))
//.concat ou (+) pode ser usado para unir strings a dados, em frases

console.log(carro.replace('tt', '77'))
console.log(carro.replace("tte", "rde"))