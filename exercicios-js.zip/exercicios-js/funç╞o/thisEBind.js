const pessoa = {
    saudaçao: 'Buenos dias fukboy',
    falar() {
        console.log(this.saudaçao)
    }
}

pessoa.falar()
const falar = pessoa.falar
falar()

//o BIND é usado para "amarrar" o objeto, para que seja o "dono" da execução de outro
const falarEmPessoa = pessoa.falar.bind(pessoa) //bind = ligar
falarEmPessoa()
//o THIS sempre sempre será o objeto passado no bind, sem alterar os atributos (no caso, pessoa.falar)