const notas = [7.25, 8.0, 8.5, 7.75, 9.25]

for(i in notas) {
    console.log(i, notas[i])
}

const pessoa = {
    nome: 'Lucas',
    sobrenome: 'Dutra',
    idade: 18,
    peso: 53,
}

for (let atributo in pessoa) { //é recomendado o uso do Let para reduzir o escopo do parametro
    console.log(`${atributo} = ${pessoa[atributo]}.`)
}