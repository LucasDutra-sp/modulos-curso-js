//operadores relacionais sempre retornam um valor booleano
console.log('1' == 1) //igual
console.log('1' === 1) //estritamente igual
console.log('4' != 4) //diferente
console.log('4' !== 4) //estritamente diferente

console.log('~~~~~~~~~~~~~~~~~~~~')
console.log(8 < 7)
console.log(8 > 7)
console.log(8 <= 7)
console.log(8 >= 7)

console.log('~~~~~~~~~~~~~~~~~~~~')
const d1 = new Date(0) //"marco-zero" do JS (01/01/1970)
const d2 = new Date(0)
console.log(d1 == d2)
console.log(d1 === d2)
console.log(d1.getDate() === d2.getDate())

console.log('~~~~~~~~~~~~~~~~~~~~')
console.log(undefined == null)
console.log(undefined === null)