console.log(typeof String)
console.log(typeof Array)
console.log(typeof Object)

String.prototype.inverter = function() {
    return this.split('').reverse().join('')
}

console.log('misca musca miquei maus'.inverter())

Array.prototype.first = function() {
    return this[0]
}

console.log([1,2,3,4,5].first())
console.log(['A', 'B', 'C'].first())

String.prototype.toString = function() {
    return 'Lascou tudo'
}

console.log('arroz'.inverter().toUpperCase())