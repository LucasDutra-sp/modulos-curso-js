const soma = function (x, y) {
    return x + y
}

const imprimirResultado = function (a, b, operacao = soma) {
    console.log(operacao(a, b))
}

imprimirResultado(3, 4)
imprimirResultado(3, 4, soma)
imprimirResultado(3, 4, function (g, h) {
    return g - h
})
imprimirResultado(3, 4, (q, w) => q * w)

const pessoa = {
    falar: function() { //acessar funçao anonima a partir de atributo de um objeto definido
        console.log('Opa')
    }
}

pessoa.falar()