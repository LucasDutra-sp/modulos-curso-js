function triangulo (ladoA, ladoB, ladoC) {
    if (ladoA == ladoB && ladoA != ladoC) {
        console.log('Triangulo Isósceles')
    } else if (ladoA == ladoB && ladoB == ladoC) {
        console.log("Triangulo Equilatero")
    } else if (ladoA != ladoB && ladoB != ladoC) {
        console.log('Triangulo Escaleno')
    }
}

triangulo(2, 2, 3)
triangulo(1, 1, 1)
triangulo(4, 6, 8)