//objeto = coleção dinâmica de pares chave/valor
const produto = new Object
produto.nome = 'cadeira'
produto['marca do produto'] = 'generica' //usando uma notação diferente
produto.preco = 220

console.log(produto) //atributos podem ser adicionados ou removidos dinamicamente
delete produto.preco
delete produto['marca do produto']
console.log(produto)

const carro = {
    modelo: 'A3 Cabriolet',
    valor: 169000,
    proprietario: {
        nome: 'Raul',
        idade: 56,
        endereco: {
            logradouro: 'Rua abc',
            numero: 1400
        }
    },
    condutores: [{
        nome: 'Junior',
        idade: 19
    }, {
        nome: 'Ana',
        idade: 42
    }],
    calcularValorSeguro: function() {
        //...
    }
}

carro.proprietario.endereco.numero = 1660
carro['proprietario']['endereco']['logradouro'] = 'Av gigante'
console.log(carro)

// delete carro.condutores
delete carro.proprietario.endereco
delete carro.calcularValorSeguro
console.log(carro)
console.log(carro.condutores)
console.log(carro.condutores.length)