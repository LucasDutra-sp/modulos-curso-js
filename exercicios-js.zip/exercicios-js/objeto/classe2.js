class Avo {
    constructor(sobrenome) {
        this.sobrenome = sobrenome
    }
}

//essa é a forma de (na sintaxe de CLASS) definir que determinada classe tem como protótipo, outra
class Pai extends Avo {
    constructor(sobrenome, profissao = 'professor') {
        super(sobrenome)
        this.profissao = profissao
    }
}

class Filho extends Pai {
    constructor() {
        super('Silva')
    }
}

const filho = new Filho
console.log(filho)