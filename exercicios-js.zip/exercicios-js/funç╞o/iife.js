//IIFE -> immediately invoked function expression

(function () {
    console.log('será executado imediatamente')
    console.log("foge do escopo mais abrangente (global)")
})()