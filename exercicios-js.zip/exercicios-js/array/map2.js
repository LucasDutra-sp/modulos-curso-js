//desafio Map

const carrinho = [
    '{ "nome": "borracha", "preço": 3.45 }',
    '{ "nome": "caderno", "preço": 13.90 }',
    '{ "nome": "kit de lápis", "preço": 41.25 }',
    '{ "nome": "caneta", "preço": 7.50 }'
]

// retornar um array apenas com os preços

const obj = carrinho.map(e => JSON.parse(e))
console.log(obj)

const precos = obj.map(e => e.preço.toFixed(2))
console.log(precos)

//desafio completo com sucesso