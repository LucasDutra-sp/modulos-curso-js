module.exports = {
    bomDia: 'Bom Dia',
    boaNoite: function() {
        return 'Boa Noite'
    },
    boaTarde: a => 'Boa tarde'
}