const peso1 = 1.0
const peso2 = Number("2.0")
//formas de atribuir numeros às variaveis

console.log(peso1, peso2)
console.log(Number.isInteger(peso1)) //(.isInteger) se é um valor inteiro
console.log(Number.isInteger(peso2))

let nota1 = 9.5
let nota2 = 6.87

const total = nota1 * peso1 + nota2 * peso2
const media = total / (peso1 + peso2)

console.log(media.toFixed(2)) //retorna o valor com quantas casas decimais você indicar
console.log(media.toString(2)) //converte valor em binário quando a função é restrita a "2"
console.log(typeof media) //(typeof) retorna o tipo do dado em questão

{
    let raio = 5.6 //raio de uma circunferencia
    const area = Math.PI * Math.pow(raio, 2) //equação Pi*raio²
    console.log(area.toFixed(4))
    //Math pode ser usado para equações exponenciais
}