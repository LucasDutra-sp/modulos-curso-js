const alunos = [
    { nome: 'joão', nota: 7.3 },
    { nome: 'maria', nota: 9.2 },
    { nome: 'pedro', nota: 9.8 }
]

// imperativo
let result1 = 0
for (let i = 0; i < alunos.length; i++) {
    result1 += alunos[i].nota
}
console.log(result1 / alunos.length)

// declarativo
const getNota = a => a.nota
const soma = (x, y) => x + y
const result2 = alunos.map(getNota).reduce(soma)

console.log(result2 / alunos.length)