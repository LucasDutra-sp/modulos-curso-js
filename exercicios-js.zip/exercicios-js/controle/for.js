let contador = -5
while(contador <= 5) {
    console.log(`Contador = ${contador}`)
    contador++
}

console.log(">~~~~~~~~~~~~~~~~~~~~<")

//For é a opção mais indicada para quantidades determinadas de repetições
for(let i = 1; i <= 10; i++) {
    console.log(`i = ${i}`)
}

const notas = [7.25, 8.0, 8.5, 7.75, 9.25]
for (let i = 0; i < notas.length; i++) {
    console.log(`nota = ${notas[i]}`)
} //essa estrutura percorre os elementos do array