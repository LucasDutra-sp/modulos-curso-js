//exemplo de Callback no browser

document.getElementsByTagName("body")[0].onclick = function (e) {
    console.log('O evento ocorreu!')
}

//eu nao consigo codar no browser :C