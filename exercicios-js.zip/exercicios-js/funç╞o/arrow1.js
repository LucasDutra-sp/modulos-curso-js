//funções ARROW sempre são anônimas //é necessario armazenar em variavel para invoca-las posteriormente

let dobro = function(a) {
    return 2 * a
}

dobro = (a) => {
    return 2 * a
}

dobro = a => 2*a
//"return" implícito //dependendo, não necessita de parenteses ou corpo da função

console.log(dobro(Math.PI))

let ola = function () { //sem parametro
    return 'olá'
}

ola = () => 'olá' //sem parametro
ola = _ => 'Olá' //possui um parametro, mas pode ser ignorado

console.log(ola())